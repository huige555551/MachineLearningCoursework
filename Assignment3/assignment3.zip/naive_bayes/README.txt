To run this code use the following steps:
1.Open Matlab
2.Navigate to this directory where the naive_bayes.m file resides.
3.In the Matlab terminal/command window type naive_bayes <training_file_name> <testing_file_name> model_type <number>
4.For model_type options are histograms,gaussians or mixtures and provide number parameter for histograms and mixtures.
5.Hit enter.